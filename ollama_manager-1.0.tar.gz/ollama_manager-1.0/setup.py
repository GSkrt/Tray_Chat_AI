from setuptools import setup

setup(
    name="ollama-manager",
    version="1.0",
    description="Ollama Docker Manager System Tray",
    long_description="A system tray application to manage Ollama Docker containers. It allows starting, stopping, and monitoring Ollama instances.",
    author="Gregor Skrt",
    author_email="gregor.skrt@gmail.com",
    py_modules=["ollama_manager"],
    install_requires=[
        "PyQt5",
        "docker",
    ],
    entry_points={
        "console_scripts": [
            "ollama-manager=ollama_manager:main",
        ],
    },
    data_files=[
        ("share/ollama-manager/images", ["images/ollama.png", "images/ollama_gpu.png"]),
        ("share/applications", ["ollama-manager.desktop"]),
        ("share/doc/ollama-manager", ["LICENSE.txt"]),
    ],
)