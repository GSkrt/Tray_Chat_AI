# Simple ollama (Docker) manager

This program manages your local LLMs. It's built for managine and visualizing status of you docker container running ollama. 
