# Copyright (c) [current year], Gregor Skrt. All rights reserved.
#
__author__ = "Gregor Skrt"
__email__ = "gregor.skrt@gmail.com"  # Replace with your email


import sys
import subprocess
import re
import html
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QFileDialog, QMessageBox, QInputDialog, QStyle, QAction, QDialog, QVBoxLayout, QTextEdit, QPushButton, QComboBox, QListWidget, QListWidgetItem, QLabel, QHBoxLayout, QWidget, QAbstractItemView
from PyQt5 import QtGui, QtCore
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QTimer
import os
import logging
import logging.handlers 

from docker import DockerClient, errors as docker_errors
import json


class OllamaTray:
    def __init__(self):
        
        self.check_timer_interval = 5000  # in milliseconds
        
        # Determine paths for packaging compatibility
        # 1. Base dir for static assets (images) relative to the script location
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Logic to find images:
        # 1. Check relative to script (Development / Manual install)
        local_image_path = os.path.join(self.base_dir, "images")
        # 2. Check standard system path (Debian/Ubuntu install)
        system_image_path = "/usr/share/ollama-manager/images"
        
        if os.path.exists(local_image_path):
            self.image_dir = local_image_path
        else:
            self.image_dir = system_image_path
        
        # 2. User data dir for writable files (settings, logs) in user's home
        self.user_data_dir = os.path.join(os.path.expanduser("~"), ".config", "ollama_manager")
        if not os.path.exists(self.user_data_dir):
            os.makedirs(self.user_data_dir)
            
        # Path for the autostart .desktop file
        self.autostart_file = os.path.join(os.path.expanduser("~"), ".config", "autostart", "ollama_manager.desktop")

        # set up logging for the app 
        logger = logging.getLogger("OllamaTray")
        logger.setLevel(logging.INFO)
        
        # set path for log directory
        log_dir = os.path.join(self.user_data_dir, "logs")
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # configure rotating file handler
        log_file_path = os.path.join(log_dir, 'OllamaManager.log')
        logger_handler = logging.handlers.RotatingFileHandler(log_file_path, maxBytes = 1024*1024, backupCount=5)
        logger_handler.setFormatter(logging.Formatter('%(asctime)s: %(levelname)s - %(message)s'))
        logger.addHandler(logger_handler)
        
        # load settings from settings.json (if exists) otherwise create one with default values
        settings_json = self.read_settings()
        self.docker_image_name = settings_json.get('ollama_container_name', 'ollama') # default to 'ollama' if not set
        self.docker_compose_path = settings_json.get('docker_compose_path', None)
        self.selected_ollama_model = settings_json.get('selected_ollama_model', None)
        self.save_settings(settings_json)
        
        self.app = QApplication(sys.argv)
        # Prevents the app from closing when there is no main window
        self.app.setQuitOnLastWindowClosed(False)

        # 1. Create the Tray Icon
        self.tray = QSystemTrayIcon()
        icon_path = os.path.join(self.image_dir, "ollama.png")
        icon = QIcon(icon_path)  # Replace with your icon path
        self.tray.setIcon(icon)
        self.tray.setVisible(True)

        # 2. Create the Menu
        self.menu = QMenu()
        
        self.status_action = QAction("Checking status...")
        self.status_action.setEnabled(False)
        self.menu.addAction(self.status_action)
        
        self.menu.addSeparator()

        self.start_action = QAction("Start Ollama")
        start_icon = QApplication.style().standardIcon(QStyle.SP_MediaPlay)
        self.start_action.setIcon(start_icon)
        self.start_action.triggered.connect(self.start_container)
        self.menu.addAction(self.start_action)

        self.stop_action = QAction("Stop Ollama")
        stop_icon = QApplication.style().standardIcon(QStyle.SP_MediaStop)
        self.stop_action.setIcon(stop_icon)
        self.stop_action.triggered.connect(self.stop_container)
        self.menu.addAction(self.stop_action)
        
        self.menu.addSeparator()

        self.choose_docker_compose_file_action = QAction("Set Docker Compose File")
        self.choose_docker_compose_file_action.triggered.connect(self.choose_docker_compose_file)
        self.menu.addAction(self.choose_docker_compose_file_action)
        
        
        self.menu.addSeparator()
        
        # add option to select ollama model from available models
        self.choose_ollama_model_action = QAction("Select Ollama Model")
        self.choose_ollama_model_action.triggered.connect(self.choose_ollama_model)
        self.menu.addAction(self.choose_ollama_model_action)
        
        self.menu.addSeparator()
        
        # add option to send prompt to ollama and show result in dialog
        self.send_prompt_action = QAction("Send Prompt to Ollama")
        # add chat icon from starndard icons
        chat_icon = QApplication.style().standardIcon(QStyle.SP_MessageBoxInformation)
        self.send_prompt_action.setIcon(chat_icon)
        self.send_prompt_action.triggered.connect(self.open_window_send_prompt_and_show_result_in_dialog)
        self.menu.addAction(self.send_prompt_action)
        
        
        self.menu.addSeparator()

        self.choose_running_docker_image_as_ollama = QAction("Choose Running Docker Image as Ollama")
        self.choose_running_docker_image_as_ollama.triggered.connect(self.choose_from_running_docker_images)
        self.menu.addAction(self.choose_running_docker_image_as_ollama)
        
        self.menu.addSeparator()
        
        self.autostart_action = QAction("Run on Startup")
        self.autostart_action.setCheckable(True)
        self.autostart_action.setChecked(os.path.exists(self.autostart_file))
        self.autostart_action.triggered.connect(self.toggle_autostart)
        self.menu.addAction(self.autostart_action)
        
       
        self.menu.addSeparator()
        
        self.quit_action = QAction("Quit")
        self.quit_action.triggered.connect(self.app.quit)
        self.menu.addAction(self.quit_action)

        self.menu.addSeparator()

        self.tray.setContextMenu(self.menu)

        # 3. Setup a Timer to check status every 5 seconds
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_status)
        self.timer.start(self.check_timer_interval)  # Check every 5 seconds
        self.update_status()
        
        
       
        
    def change_timer_interval_input(self): 
        interval, ok = QInputDialog.getInt(None, "Set Status Check Interval", "Enter interval in seconds:", self.check_timer_interval, 1000, 60000, 1000)
        if ok:
            self.check_timer_interval = interval*1000 # convert to milliseconds
            self.timer.setInterval(self.check_timer_interval)
            self.show_status_message("Interval Updated", f"Status check interval set to {(self.check_timer_interval/1000)} s.")
            
    
        
    def show_status_message(self, title, message, duration=3000):
        self.tray.showMessage(title, message, QSystemTrayIcon.Information, duration)
        
        
    def open_window_send_prompt_and_show_result_in_dialog(self):
        # Create a dialog window for sending prompts
        dialog = QDialog()
        dialog.setWindowTitle("Chat with Ollama models")
        layout = QVBoxLayout()
        # add resize to maximum button to dialog 
        dialog.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.WindowMinMaxButtonsHint | QtCore.Qt.WindowCloseButtonHint)
        
        
        
        # initial size of the chat dialog
        dialog.resize(600, 600)
        
        # first call function to sellect ollama model if not selected yet 
        if not self.selected_ollama_model:
            self.choose_ollama_model()
        
        font = QtGui.QFont()
        font.setPointSize(12)
        
        # Chat Display (History)
        chat_display = QListWidget()
        chat_display.setStyleSheet("QListWidget { background-color: #ECE5DD; border: none; }")
        chat_display.setSelectionMode(QAbstractItemView.NoSelection)
        
        # Handle resize to update bubble widths dynamically
        def chat_resize_event(event):
            QListWidget.resizeEvent(chat_display, event)
            new_max_width = int((event.size().width() - 50) * 0.85)
            for i in range(chat_display.count()):
                item = chat_display.item(i)
                widget = chat_display.itemWidget(item)
                if widget:
                    label = widget.findChild(QLabel)
                    if label:
                        label.setMaximumWidth(new_max_width)
                        widget.layout().activate()
                        widget.adjustSize()
                        item.setSizeHint(widget.sizeHint())
            chat_display.doItemsLayout()
        chat_display.resizeEvent = chat_resize_event
        
        layout.addWidget(chat_display)
        
        # Input Area
        prompt_input = QTextEdit()
        prompt_input.setFont(font)
        prompt_input.setMaximumHeight(100)
        prompt_input.setPlaceholderText("Type your message here... (Press Enter to send)")
        layout.addWidget(prompt_input)

        send_button = QPushButton("Send")
        
        # Initialize chat history for this session
        dialog.chat_history = []
        
        # Handle Enter key to send
        def keyPressEvent(event):
            if event.key() == QtCore.Qt.Key_Return and not (event.modifiers() & QtCore.Qt.ShiftModifier):
                send_button.click()
            else:
                QTextEdit.keyPressEvent(prompt_input, event)
        prompt_input.keyPressEvent = keyPressEvent
        
        send_button.clicked.connect(lambda: self.send_prompt_and_show_result(prompt_input, chat_display, dialog))
        layout.addWidget(send_button)

        dialog.setLayout(layout)
        dialog.exec_()

    def send_prompt_and_show_result(self, prompt_input, chat_display, dialog):
        prompt = prompt_input.toPlainText().strip()
        if not prompt:
            return

        def add_bubble(text, role):
            item = QListWidgetItem()
            widget = QWidget()
            layout = QHBoxLayout()
            
            # Normalize newlines
            text = text.replace("\r\n", "\n")
            
            parts = re.split(r'(```.*?```)', text, flags=re.DOTALL)
            final_html_parts = []
            
            for part in parts:
                if part.startswith("```") and part.endswith("```"):
                    content = part[3:-3]
                    # Remove language identifier if present
                    match = re.match(r'^\s*([a-zA-Z0-9+\-#]+)\n', content)
                    if match:
                        content = content[match.end():]
                    
                    escaped_content = html.escape(content, quote=False)
                    # Use table for background color support in QLabel rich text
                    code_html = f'<br><table border="0" cellpadding="10" bgcolor="#2b2b2b" width="100%"><tr><td><pre style="color: #f8f8f2;">{escaped_content}</pre></td></tr></table><br>'
                    final_html_parts.append(code_html)
                else:
                    # Heuristic: If Assistant response looks like hard-wrapped text (and not code), unwrap it.
                    if role == "Assistant" and "```" not in text:
                        part = part.replace("\n\n", "[[PARAGRAPH]]").replace("\n", " ").replace("[[PARAGRAPH]]", "\n\n")
                    
                    escaped_part = html.escape(part, quote=False).replace("\n", "<br>")
                    if role == "Assistant":
                        escaped_part = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', escaped_part)
                    final_html_parts.append(escaped_part)
            
            final_html = "".join(final_html_parts)
            
            
            # set qlabel width as percentage of chat display width make sure this works on resize too
            
            current_width = chat_display.width()
            if chat_display.viewport().width() > 0:
                current_width = chat_display.viewport().width()
            
            label_width = int((current_width - 50) * 0.85) 
            label = QLabel(final_html)
            label.setWordWrap(True)
            label.setMaximumWidth(label_width) 
            label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            label.setOpenExternalLinks(True)
            
            if role == "User":
                label.setStyleSheet("background-color: #DCF8C6; color: black; border-radius: 10px; padding: 10px; font-size: 12pt;")
                layout.addStretch()
                layout.addWidget(label)
            else:
                label.setStyleSheet("background-color: #FFFFFF; color: black; border-radius: 10px; padding: 10px; font-size: 12pt;")
                layout.addWidget(label)
                layout.addStretch()
            
            layout.setContentsMargins(10, 5, 10, 5)
            widget.setLayout(layout)
            item.setSizeHint(widget.sizeHint())
            chat_display.addItem(item)
            chat_display.setItemWidget(item, widget)
            chat_display.scrollToBottom()

        # Display User Message
        add_bubble(prompt, "User")
        
        prompt_input.clear()
        QApplication.processEvents()

        # Construct Contextual Prompt
        full_prompt = ""
        for msg in dialog.chat_history:
            full_prompt += f"{msg['role']}: {msg['content']}\n"
        full_prompt += f"User: {prompt}\nAssistant:"

        QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            result = self.send_promt_to_ollama(full_prompt)
        finally:
            QApplication.restoreOverrideCursor()

        if result:
            # Display AI Response
            add_bubble(result, "Assistant")
            
            # Update History
            dialog.chat_history.append({"role": "User", "content": prompt})
            dialog.chat_history.append({"role": "Assistant", "content": result.strip()})
            
            return result 
        else:
            add_bubble("Error: Failed to get response.", "Assistant")
            return None

    def send_promt_to_ollama(self, prompt):
        """Sends a prompt to the Ollama container via docker python package."""
        try:
            client = DockerClient.from_env()
            container = client.containers.get(self.docker_image_name)
            if container.status == "running":
                # Execute the ollama command inside the container
                # use selected ollama model if set
                if self.selected_ollama_model:
                    # Use subprocess to pipe input to stdin, avoiding shell quoting issues
                    cmd = ["docker", "exec", "-i", self.docker_image_name, "ollama", "run", self.selected_ollama_model]
                    result = subprocess.run(cmd, input=prompt.encode('utf-8'), capture_output=True)
                    output = result.stdout.decode('utf-8')
                    # Remove ANSI escape codes
                    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
                    return ansi_escape.sub('', output)
                else:
                    return "Error: No model selected. Please select a model."
            else:
                logging.error("Ollama container is not running.")
                return None
        except Exception as e:
            logging.error(f"Error sending prompt: {e}")
            return None
        
    def list_ollama_models(self):
        """Lists available Ollama models by querying the container."""
        try:
            client = DockerClient.from_env()
            container = client.containers.get(self.docker_image_name)
            if container.status == "running":
                exec_log = container.exec_run("ollama list", stdout=True, stderr=True)
                output = exec_log.output.decode('utf-8')
                return output
            else:
                logging.error("Ollama container is not running.")
                return None
        except docker_errors.DockerException as e:
            logging.error(f"Docker error: {e}")
            return None
        
    def choose_ollama_model(self):
        # Placeholder for choosing Ollama model from available models
        models_output = self.list_ollama_models()
        if models_output:
            models = [line.split()[0] for line in models_output.splitlines() if line]
            item, ok = QInputDialog.getItem(None, "Select Ollama Model", "Available Models:", models, 0, False)
            if ok and item:
                QMessageBox.information(None, "Model Selected", f"You selected: {item}")
                self.selected_ollama_model = item
                
                # store selected model in settings to persist between sessions 
                settings = self.read_settings()
                settings['selected_ollama_model'] = item
                self.save_settings(settings)
                
                # add menu text to show selected model, show it in bold 
                self.choose_ollama_model_action.setText(f"Select Ollama Model (Selected: {item})")
                
        else:
            QMessageBox.warning(None, "No Models", "Could not retrieve Ollama models.")
        

    

    def update_status(self):
        """Runs a shell command to check if the Ollama container is running."""
        try:
            # Check if container 'ollama' is running
            result = subprocess.run(
                ["docker", "inspect", "-f", "{{.State.Running}}|{{.HostConfig.Runtime}}|{{json .HostConfig.DeviceRequests}}", self.docker_image_name],
                capture_output=True, text=True
            )
            
            output = result.stdout.strip().split("|")
            is_running = output[0] == "true"
            runtime = output[1] if len(output) > 1 else ""
            device_requests = output[2] if len(output) > 2 else "null"
            
            if is_running:
                mode = "CPU"
                # Check if runtime is nvidia or if there are GPU device requests
                if runtime == "nvidia" or (device_requests != "null" and "gpu" in device_requests.lower()):
                    mode = "GPU 🚀"
                    # update tray icon image to show gpu mode
                    gpu_icon_path = os.path.join(self.image_dir, "ollama_gpu_running.png")
                    self.tray.setIcon(QIcon(gpu_icon_path))
                else:
                    # reset to default icon for cpu mode
                    default_icon_path = os.path.join(self.image_dir, "ollama_cpu_running.png")
                    self.tray.setIcon(QIcon(default_icon_path))
                    
                self.status_action.setText(f"Ollama: Running ({mode})")
                # You could change the icon here too: self.tray.setIcon(QIcon("green.png"))
                self.start_action.setVisible(False)
                self.stop_action.setVisible(True)
                
            else:
                # set tray icon to not running 
                not_running_icon_path = os.path.join(self.image_dir, "ollama_not_running.png")
                self.tray.setIcon(QIcon(not_running_icon_path))
                
                # change icon to show stopped status
                self.status_action.setText("Ollama: Stopped ❌")
                self.start_action.setVisible(True)
                self.stop_action.setVisible(False)
                
        except Exception:
            self.status_action.setText("Ollama: Not Found")
            self.start_action.setEnabled(False)
            self.stop_action.setEnabled(False)
            
    def choose_from_running_docker_images(self):
        # List running docker containers and let user choose one to set as Ollama
        try:
            client = DockerClient.from_env()
            containers = client.containers.list()
            container_names = [container.name for container in containers]

            if not container_names:
                QMessageBox.information(None, "No Running Containers", "There are no running Docker containers.")
                return

            item, ok = QInputDialog.getItem(None, "Select Docker Container", "Running Containers:", container_names, 0, False)
            if ok and item:
                # Here you would store the selected container name and use it in start/stop methods
                QMessageBox.information(None, "Container Selected", f"You selected: {item}")
                settings = self.read_settings()
                settings['ollama_container_name'] = item
                self.docker_image_name = item
                self.save_settings(settings)
                self.update_status()
        except docker_errors.DockerException as e:
            logging.error(f"Docker error: {e}")
            QMessageBox.critical(None, "Docker Error", f"An error occurred while accessing Docker: {e}")
            
    def choose_docker_compose_file(self):
        # Placeholder for file dialog to choose docker compose file

        # get users home directory, use it as start path it should be working on windows mac and linux too...
        home = os.path.expanduser("~")
        file_manager_string = "Select docker-compose.yml file to start and stop Ollama container"
        file_path, selected_filter = QFileDialog.getOpenFileName(None, file_manager_string, home, "YAML Files (*.yml);;All Files (*)")
        
        settings_json = self.read_settings()
        settings_json['docker_compose_path'] = file_path
        self.docker_compose_path = file_path
        self.save_settings(settings_json)
        if file_path:
            QMessageBox.information(None, "File Selected", f"You selected: {file_path}\n) ")
            # Here you would store the selected file path and use it in start/stop methods
            
        else:
            print("No file selected.")
            

    def read_settings(self):
        try:
            settings_path = os.path.join(self.user_data_dir, "settings.json")
            with open(settings_path, "r") as f:
                settings = json.load(f)
                return settings
        except Exception as e:
            logging.error(f"Failed to read settings: {e}")
            # Return empty dict in case of failure to read settings file, so we don't have None when trying to access its properties later on
            return {}
        
    def save_settings(self, settings):
        try:
            settings_path = os.path.join(self.user_data_dir, "settings.json")
            with open(settings_path, "w") as f:
                json.dump(settings, f)
        except Exception as e:
            logging.error(f"Failed to save settings: {e}")
    
    
    def start_container(self):
        # Start the Ollama Docker container using docker compose file or docker command
        if self.docker_compose_path and os.path.exists(self.docker_compose_path):
            dir_path = os.path.dirname(self.docker_compose_path)
            subprocess.run(["docker-compose", "-f", self.docker_compose_path, "up", "-d"], cwd=dir_path)
        else:
            # check for docker containers (that are not running) named ollama and start it
            try:
                client = DockerClient.from_env()
                container = client.containers.get(self.docker_image_name)
                if container.status != "running":
                    container.start()
                    self.show_status_message("Ollama Started", f"Ollama container '{self.docker_image_name}' has been started.")
            except Exception as e:
                logging.error(f"Failed to start Ollama container: {e}")
            
        self.update_status()

    def stop_container(self):
        # stop docker compose service or docker command
        try:
            client = DockerClient.from_env()
            container = client.containers.get(self.docker_image_name)
            container.stop()
            self.show_status_message("Ollama Stopped", f"Ollama container '{self.docker_image_name}' has been stopped.")
        except Exception as e:
            logging.error(f"Failed to stop Ollama container: {e}")
        self.update_status()
        
    def toggle_autostart(self):
        if self.autostart_action.isChecked():
            autostart_dir = os.path.dirname(self.autostart_file)
            if not os.path.exists(autostart_dir):
                os.makedirs(autostart_dir)
            
            # Use sys.executable to ensure the same python interpreter (e.g. venv) is used
            exec_cmd = f'{sys.executable} "{os.path.abspath(__file__)}"'
            icon_path = os.path.join(self.image_dir, "ollama.png")
            
            desktop_entry = f"""[Desktop Entry]
Type=Application
Name=Ollama Docker Manager
Exec={exec_cmd}
Icon={icon_path}
Comment=Manage Ollama Docker Containers
Terminal=false
Categories=Utility;
StartupNotify=false
"""
            try:
                with open(self.autostart_file, "w") as f:
                    f.write(desktop_entry)
                self.show_status_message("Settings Saved", "Run on Startup enabled.")
                logging.info(f"Autostart file created in user's autostart directory. \n {desktop_entry}")
            except Exception as e:
                logging.error(f"Failed to write autostart file: {e}")
                self.autostart_action.setChecked(False)
        else:
            if os.path.exists(self.autostart_file):
                try:
                    os.remove(self.autostart_file)
                    self.show_status_message("Settings Saved", "Run on Startup disabled.")
                    logging.info(f"Autostart file removed from user's autostart directory {self.autostart_file}.")
                except Exception as e:
                    logging.error(f"Failed to remove autostart file: {e}")

    def run(self):
        sys.exit(self.app.exec_())

def main():
    tray = OllamaTray()
    tray.run()

if __name__ == "__main__":
    main()